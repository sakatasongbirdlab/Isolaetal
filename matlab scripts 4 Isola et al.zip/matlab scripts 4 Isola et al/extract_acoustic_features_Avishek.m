function struct=extract_acoustic_features_new_Avishek()

% This script will compute the duration, mean frequency, spectral entropy, entropy of the amplitude envelope, 
% spectrotemporal entropy, and mean loudness of individual syllables.
% It will not calculate features for syllables labelled '0' or '-'
% It will output a structure or a text file
% It assumes that files are wav files (e.g., files recorded using SAP) so
% Fs=44100 (as default)

% 22/10/2019 (Avishek Paul): Changed line 66 so that lableindexes are printed instead of
% 'all'. Also commented out line 68 and line 58 as Label index printing was
% not needed.

global labelIndex %array of the letters of labels in use
global filetype
% global id_threshold

struct=[];

% designative default filetype and sampling rate
filetype='w';
Fs=44100; 

[training_fid] = get_training_batchfile; % get batch file of songs in which acoustic features will be extracted

[templateSylls, index, labelIndex, temp_id] = read_training(training_fid);

% Makes the template
templates = make_templates(templateSylls);
save 'template.mat' labelIndex index templates temp_id;
                    
disp('The syllables that have been labeled are (labelIndex):     ')
disp(labelIndex')

%concatenate index and templates outputs (index = syllable index)
datavector=[index,templates];
reduced_vect=[];

note=input('Select syllable to evaluate (e.g., all, abcdef, etc)?  ','s');
if note=='all'| note=='All'
    reduced_vect=datavector;
else
    note_index=findstr(labelIndex',note);
    num=1;
    %look for note of interest
    for i=1:length(datavector)
        if datavector(i)==note_index
           reduced_vect=[reduced_vect;datavector(i,:)]; % first column is note_index
        end 
    end
end

%Write the data to a file?
write_data=input('Do you want to write the data to a textfile  (y or n)?  ','s');
if write_data=='y' | write_data=='yes'
    textfilename=input('What is the name of the textfile (end with .txt)?  ','s');
    fid=fopen(textfilename,'w');
    fprintf(fid,'Syllable\t');
%     fprintf(fid,'labelIndex\t'); % letters are turned into numbers based on list of 
    fprintf(fid,'Mean Freq\t');
    fprintf(fid,'Spec Density Ent\t');
    fprintf(fid,'Duration\t');
    fprintf(fid,'Loudness ent\t');
    fprintf(fid,'Spectrotemp Ent\t');
    fprintf(fid,'Log Mean Loud\n');
    
    for i=1:length(reduced_vect)
        fprintf(fid,'%s\t',labelIndex(reduced_vect(i,1)));
%         fprintf(fid,'%6.2f\t',reduced_vect(i,1));
        fprintf(fid,'%6.2f\t',reduced_vect(i,2));
        fprintf(fid,'%6.2f\t',reduced_vect(i,3));
        fprintf(fid,'%6.2f\t',reduced_vect(i,4));
        fprintf(fid,'%6.2f\t',reduced_vect(i,5));
        fprintf(fid,'%6.2f\t',reduced_vect(i,6));
        fprintf(fid,'%6.2f\n',reduced_vect(i,7));
    end
    
    fclose(fid);
end

% output the structure regardless of whether the text file is created
%     struct.syllable; struct.meanfreq; struct.specdensent; struct.duration; 
%     struct.loudnessent; struct.specttempent; struct.meanloud;

for i=1:length(reduced_vect)
        struct.syllable(i)=reduced_vect(i,1);
        struct.meanfreq(i)=reduced_vect(i,2);
        struct.specdensent(i)=reduced_vect(i,3);
        struct.duration(i)=reduced_vect(i,4);
        struct.loudnessent(i)=reduced_vect(i,5);
        %struct.freqslope(i)=reduced_vect(i,6);
        %struct.ampslope(i)=reduced_vect(i,7);
        struct.specttempent(i)=reduced_vect(i,6);
        %struct.peakloud(i)=reduced_vect(i,9);
        struct.meanloud(i)=reduced_vect(i,7);
end
    
output=struct;

%end
    
fclose('all');

%-------------------------------------------------------------------------------

function [training_fid] = get_training_batchfile
% Prompts user for training batchfile

global train_path

training_fid = -1;
trainingfile = 0;
   disp('Select Batchfile (of wav files)'); % e.g., batchfile of wav files
   [trainingfile, train_path]=uigetfile('*','Select Batchfile');
   training_fid=fopen([train_path, trainingfile]);
   if training_fid == -1 | trainingfile == 0
        error(['Cannot open file: ' trainingfile]);
   end

%--------------------------------------------------------------------------

function [sylls, index, labelIndex, id] = read_training(training_fid)
% Gets syllables and labels from training batchfile

global train_path
global filetype

sylls = [];
index =[];
labelIndex = [];
id=[];

while 1
   %get soundfile name
     soundfile = fscanf(training_fid,'%s',1);
   %end when there are no more notefiles
     if isempty(soundfile)
        break
     end
     
   if (~(soundfile(1)=='/'))&(~strcmp(train_path,pwd))
       soundfile=[train_path,soundfile];
   end
   if (soundfile(end-4:end)=='.filt')   % if the batch file is of .filt files...
       notefile=[soundfile(1:end-5),'.not.mat'];
       filtfile=soundfile;
       if ~strcmp(filetype,'filt')
           disp('Filetype .filt found.')
       end
       filetype='filt';
   else
       if (soundfile(end-4:end)=='.cbin')  % if the batch file is of .cbin files...
           notefile=[soundfile, '.not.mat'];
           filtfile=[soundfile, '.filt'];
           if ~(strcmp(filetype,'obs0r')|strcmp(filetype,'obs1r'))
               disp('Filetype .cbin found.')
           end
           filetype='obs0r';
       else                              % if the files end in neither .cbin nor .filt
           notefile=[soundfile, '.not.mat'];
           filtfile=[soundfile, '.filt'];
           if ~(strcmp(filetype,'w'))
               disp('Assuming wave file format (file does not end in .cbin or .filt)')
           end
           filetype='w';
       end
   end

   % Skip file if it doesn't exist or has no .not.mat file
    if ~((exist(soundfile)|exist(filtfile)) & exist(notefile))   
        disp(['Skipping ', soundfile, ' (file or .not.mat file does not exist)'])
        continue
    end
    
    % Read filt file if it exists, otherwise read and filter raw song, saving a copy
    if exist(filtfile)
       [filtsong, fs]=read_filt(filtfile);
    else
        disp(['   Filtering ',soundfile])
        [song,fs]=soundin('', soundfile, filetype);
        filtsong=bandpass(song,fs,300,8000);
        write_filt(filtfile, filtsong, fs);
    end
   
    load(notefile);
        
    %make sure labels is a column vector
    [x,y]=size(labels);
    if y > x
        labels=labels';
    end 
    
    disp(['Processing ' soundfile ' . . .']); 
    
    % convert onsets and offsets from ms to samples
    on = fix(onsets.*fs/1000);
    off = fix(offsets.*fs/1000);

    % For each syllable in the song file
    for i = 1:size(labels,1)
        
        % Skip certain labels
        if labels(i)=='0'|labels(i)=='-'
            continue
        end
           
        % Add syll
        sylls = [sylls; {filtsong(on(i):off(i))}];
        % Add label to index if it isn't there already
        if isempty(labelIndex) | isempty(find(labelIndex == labels(i)))
            labelIndex = [labelIndex; labels(i)];
        end
        % add label to index of sylls, in numerical form
        index = [index; find(labelIndex == labels(i))];
        id = [id; {soundfile},{onsets(i)}];
        
    end 
end

%-------------------------------------------------------------------------------


function templates = make_templates(templateSylls)

% Calculates feature vectors for all example syllables

disp('Making templates.');

templates = [];
Fs=44100;
for i = 1:size(templateSylls,1)
    templates = [templates; feature_vect_extract(templateSylls{i},Fs)];
    if mod(i,100)==0                                                  
        disp([num2str(i),' of ',num2str(size(templateSylls,1)),' completed.'])
    end
end

%-------------------------------------------------------------------------------

