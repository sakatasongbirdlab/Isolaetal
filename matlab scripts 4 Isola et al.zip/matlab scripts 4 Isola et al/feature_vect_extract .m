function featvect=feature_vect_extract(syllable,Fs)

% featvect=FEATURE_VECT_EXTRACT(syllable,Fs)
% Returns a row vector which is the feature vector of a particular syllable.

   Dur=length(syllable)/Fs;  % Duration of the syllable
   if ~(length(syllable)>1)
       disp('ERROR: EMPTY SYLLABLE IN FEATURE_VECT!!')
       return
   end
   
   % Calculate the loudness of the syllable (the squared amplitude, smoothed with a 2 ms time window)
   window=ceil(0.002*Fs);
   kern=[];
   for i=1:window;  %  A broad gaussian window
       kern(i)=exp(-(i-window/2)*(i-window/2)/(2.5*window));
   end   
   loud=smooth_ev(syllable.*syllable,kern')/sum(kern);  % Calculate loudness

   % Find the peak loudness and record it's amplitude and timing
   meanLoud=mean(loud);
   
   % Normalize;
   loud=loud/sum(loud);
   
   % Calculate the spectral density of the syllable
   [sd,sdf]=specgram(syllable,length(syllable),Fs);
   sd=sd(find(sdf<8000));    % Above 8000 Hz, filtered out anyway
   sdf=sdf(find(sdf<8000));
   sd=abs(sd);  % Throw away relative phase information
   % Normalize
   sd=sd/sum(sd);
   
   % Calculate the spectral density of each half of the syllable
   [sds,sdfs]=specgram(syllable,1+ceil(length(syllable)/2),Fs);
	       sd1=abs(sds(:,1));
	       sd2=abs(sds(:,2));
	       sum1=sum(sd1);
	       sum2=sum(sd2);
	       f1=sum(sd1.*sdfs)/sum1;
	       f2=sum(sd2.*sdfs)/sum2;

   % Calculate the peak and spectral entropy of the full spectrogram
   [spec,specf]=specgram(syllable,256,Fs,205);
   for i=1:size(spec,1)*size(spec,2)
        unwrap(i)=abs(spec(i));
   end
   [y,index]=sort(unwrap);
   spec_peak=mean(unwrap(index>0.99*length(unwrap)));
   unwrap=unwrap/sum(unwrap);
   spec_ent=-sum(unwrap.*log2(unwrap))/log2(length(unwrap));

   % Output the Relevant Features
   featvect(1)=sum(sd.*sdf)/100;                        % First: The Mean Frequency; 
   featvect(2)=-100*sum(sd.*log2(sd))/log2(length(sd)); % Second: Entropy of the spectral density 
                                                        % range: 0 to 100; 100 = white noise; 0 = pure note;
   featvect(3)=Dur*1000;                                % Third: Duration of Syllable (in ms);
   featvect(4)=-100*sum(loud.*log2(loud))/log2(length(loud));    % Fourth: Entropy of the loudness vs. time 
                                                                  %(range: 0 to 100; 100 = flat amplitude; 0 = one very sharp peak)
   featvect(5)=100*spec_ent;                            % Fifth: spectrotemp entropy; diff between sweep and stack
   featvect(6)=log10(meanLoud);                                % Sixth: log of Mean Loudness

   
   return;

